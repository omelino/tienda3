<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklanguages}leo_funiturestore>blocklanguages_d33f69bfa67e20063a8905c923d9cf59'] = 'Блок выбора языков';
$_MODULE['<{blocklanguages}leo_funiturestore>blocklanguages_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'Добавляет блок, позволяющий посетителям выбирать язык магазина.';
