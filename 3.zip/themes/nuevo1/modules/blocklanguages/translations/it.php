<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklanguages}leo_funiturestore>blocklanguages_d33f69bfa67e20063a8905c923d9cf59'] = 'Blocco di selezione delle lingue';
$_MODULE['<{blocklanguages}leo_funiturestore>blocklanguages_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'Aggiunge un blocco che consente al cliente di selezionare una lingua per i contenuti del tuo negozio.';
