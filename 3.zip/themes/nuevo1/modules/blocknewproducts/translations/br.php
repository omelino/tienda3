<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_f7c34fc4a48bc683445c1e7bbc245508'] = 'Novo bloco de produtos';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_d3ee346c7f6560faa13622b6fef26f96'] = 'Exibe um bloco com os produtos recém-adicionados.';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_1cd777247f2a6ed79534d4ace72d78ce'] = 'Por favor, preencha o campo \"produtos mostrados\".';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_73293a024e644165e9bf48f270af63a0'] = 'Número inválido.';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_c888438d14855d7d96a2724ee9c306bd'] = 'Configurações atualizadas';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_f4f70727dc34561dfde1a3c529b6205c'] = 'Configurações';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_26986c3388870d4148b1b5375368a83d'] = 'Produtos para mostrar';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_3ea7689283770958661c27c37275b89c'] = 'Defina o número de produtos a serem apresentados neste bloco';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_85dd6b2059e1ff8fbefcc9cf6e240933'] = 'Número de dias em que o produto é considerado \"novo\"';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_24ff4e4d39bb7811f6bdf0c189462272'] = 'Mostra sempre este bloco';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_d68e7b860a7dba819fa1c75225c284b5'] = 'Mostrar o bloco mesmo que não tenha produtos listados.';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Ativado';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desativado';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_9ff0635f5737513b1a6f559ac2bff745'] = 'Novidades';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_43340e6cc4e88197d57f8d6d5ea50a46'] = 'Exibir';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_60efcc704ef1456678f77eb9ee20847b'] = 'Todos recém adicionados';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_18cc24fb12f89c839ab890f8188febe8'] = 'Nenhuma novidade no momento';
$_MODULE['<{blocknewproducts}leo_funiturestore>blocknewproducts_home_0af0aac2e9f6bd1d5283eed39fe265cc'] = 'Nenhuma novidade no momento.';
$_MODULE['<{blocknewproducts}leo_funiturestore>tab_a0d0ebc37673b9ea77dd7c1a02160e2d'] = 'Recém chegados';
