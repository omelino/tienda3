<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcurrencies}leo_funiturestore>blockcurrencies_f7a31ae8f776597d4282bd3b1013f08b'] = 'Blok walut';
$_MODULE['<{blockcurrencies}leo_funiturestore>blockcurrencies_80ed40ee905b534ee85ce49a54380107'] = 'Dodaj blok wyboru waluty';
$_MODULE['<{blockcurrencies}leo_funiturestore>blockcurrencies_386c339d37e737a436499d423a77df0c'] = 'Waluta';
