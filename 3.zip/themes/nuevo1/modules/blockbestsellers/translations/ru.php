<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_9862f1949f776f69155b6e6b330c7ee1'] = 'Лидеры продаж';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_ed6476843a865d9daf92e409082b76e1'] = 'Добавляет блок, отображющий лидеров продаж.';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки обновлены';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_26986c3388870d4148b1b5375368a83d'] = 'Число отображаемых товаров';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_2b21378492166b0e5a855e2da611659c'] = 'Определить количество товаров, отображаемых в этом блоке';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_24ff4e4d39bb7811f6bdf0c189462272'] = 'Всегда отображать блок';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_84b0c5fdef19ab8ef61cd809f9250d85'] = 'Показывать блок, даже если нет лидеров продаж.';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Включено';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_b9f5c797ebbf55adccdd8539a65a0241'] = 'Отключено';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers-home_09a5fe24fe0fc9ce90efc4aa507c66e7'] = 'На данный момент нет лидеров продаж.';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_1d0a2e1f62ccf460d604ccbc9e09da95'] = 'Просмотреть самые продаваемые товары';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = 'Популярные товары';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_eae99cd6a931f3553123420b16383812'] = 'Все популярные товары';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_f7be84d6809317a6eb0ff3823a936800'] = 'На данный момент нет лидеров продаж';
$_MODULE['<{blockbestsellers}leo_funiturestore>tab_d7b2933ba512ada478c97fa43dd7ebe6'] = 'Лидеры продаж';
