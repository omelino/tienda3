<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_9862f1949f776f69155b6e6b330c7ee1'] = 'Blocco dei più venduti';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_ed6476843a865d9daf92e409082b76e1'] = 'Aggiunge un blocco che mostra i prodotti più venduti del tuo negozio.';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_26986c3388870d4148b1b5375368a83d'] = 'Prodotti da visualizzare';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_2b21378492166b0e5a855e2da611659c'] = 'Determina il numero dei prodotti da mostrare in questo blocco';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_24ff4e4d39bb7811f6bdf0c189462272'] = 'Visualizza sempre questo blocco';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_84b0c5fdef19ab8ef61cd809f9250d85'] = 'Mostra il blocco anche se non sono presenti migliori vendite.';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Attivato';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disattivato';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers-home_09a5fe24fe0fc9ce90efc4aa507c66e7'] = 'Elenco prodotti più venduti non disponibile in questo momento.';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_1d0a2e1f62ccf460d604ccbc9e09da95'] = 'Vedi i prodotti più venduti';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = 'I più venduti';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_eae99cd6a931f3553123420b16383812'] = 'Tutte le migliori vendite';
$_MODULE['<{blockbestsellers}leo_funiturestore>blockbestsellers_f7be84d6809317a6eb0ff3823a936800'] = 'Elenco prodotti più venduti non disponibile in questo momento';
$_MODULE['<{blockbestsellers}leo_funiturestore>tab_d7b2933ba512ada478c97fa43dd7ebe6'] = 'Migliori vendite';
