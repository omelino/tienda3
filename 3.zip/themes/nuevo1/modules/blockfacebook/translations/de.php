<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockfacebook}leo_funiturestore>blockfacebook_43d541d80b37ddb75cde3906b1ded452'] = 'Block \"Auf Facebook abonnieren\"';
$_MODULE['<{blockfacebook}leo_funiturestore>blockfacebook_e2887a32ddafab9926516d8cb29aab76'] = 'Zeigt einen Block an, auf dem man Ihre Facebook-Seite abonnieren kann.';
$_MODULE['<{blockfacebook}leo_funiturestore>blockfacebook_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Einstellungen aktualisiert';
$_MODULE['<{blockfacebook}leo_funiturestore>blockfacebook_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockfacebook}leo_funiturestore>blockfacebook_c98cf18081245e342d7929c117066f0b'] = 'Facebook-Link (vollständige URL erforderlich)';
$_MODULE['<{blockfacebook}leo_funiturestore>blockfacebook_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blockfacebook}leo_funiturestore>blockfacebook_374fe11018588d3d27e630b2dffb7909'] = 'Folgen Sie uns auf Facebook';
$_MODULE['<{blockfacebook}leo_funiturestore>preview_374fe11018588d3d27e630b2dffb7909'] = 'Folgen Sie uns auf Facebook';
$_MODULE['<{blockfacebook}leo_funiturestore>blockfacebook_d85544fce402c7a2a96a48078edaf203'] = 'Facebook';
