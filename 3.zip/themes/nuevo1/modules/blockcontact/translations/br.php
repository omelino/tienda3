<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_df8f3e2cd8d1acbb2d1aa46a45045ec5'] = 'Bloco de Contato';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_318ed85b9852475f24127167815e85d9'] = 'Permite inserir informações adicionais para um outro serviço de contato';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configurações atualizadas.';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_f4f70727dc34561dfde1a3c529b6205c'] = 'Configurações';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_90a613a116f4bd9390ff7379a114f8d7'] = 'Este bloco exibe no cabeçalho seu nº de telefone (\'Ligue-nos agora\'), e um link para a página \'Fale Conosco\'.';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_5f6e75192756d3ad45cff4a1ee0a45ba'] = 'Para editar o e-mail para a página \'Fale Conosco\': você deve ir à página \'Contatos\', sob o menu \'Cliente\'.';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_ccffe09c1cd18f73ad1f76762fded097'] = 'Para editar detalhes de contato no rodapé: você deve ir ao módulo \'Bloco Informação de Contato\'.';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_7551cf1a985728fa2798db32c2ff7887'] = 'Telefone';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_52e878b67e9d94d25425231162ef5133'] = 'Inserir aqui seus detalhes de contato de serviço.';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_02d4482d332e1aef3437cd61c9bcc624'] = 'Fale conosco';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_75858d311c84e7ba706b69bea5c71d36'] = '           Não encontrou o produto           desejado, envie-nos um           e-mail.';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_673ae02fffb72f0fe68a66f096a01347'] = 'Telefone:';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_736c5a7e834b7021bfa97180fc453115'] = 'Contate nosso Atendimento ao Cliente!';
$_MODULE['<{blockcontact}leo_funiturestore>nav_02d4482d332e1aef3437cd61c9bcc624'] = 'Fale conosco';
$_MODULE['<{blockcontact}leo_funiturestore>nav_320abee94a07e976991e4df0d4afb319'] = 'Ligue-nos agora:';
$_MODULE['<{blockcontact}leo_funiturestore>blockcontact_9cfc9b74983d504ec71db33967591249'] = 'Fale Conosco';
$_MODULE['<{blockcontact}leo_funiturestore>nav_9cfc9b74983d504ec71db33967591249'] = 'Fale conosco';
