<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}leo_funiturestore>blockpaymentlogo_eaaf494f0c90a2707d768a9df605e94b'] = 'Blok logo płatności';
$_MODULE['<{blockpaymentlogo}leo_funiturestore>blockpaymentlogo_3fd11fa0ede1bd0ace9b3fcdbf6a71c9'] = 'Dodaje blok, który wyświetla wszystkie Twoje logo płatności.';
$_MODULE['<{blockpaymentlogo}leo_funiturestore>blockpaymentlogo_efc226b17e0532afff43be870bff0de7'] = 'Ustawienia zostały zaktualizowane.';
$_MODULE['<{blockpaymentlogo}leo_funiturestore>blockpaymentlogo_5c5e5371da7ab2c28d1af066a1a1cc0d'] = 'Strona CMS nie jest dostępna';
$_MODULE['<{blockpaymentlogo}leo_funiturestore>blockpaymentlogo_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{blockpaymentlogo}leo_funiturestore>blockpaymentlogo_829cb250498661a9f98a58dc670a9675'] = 'Strona docelowa linku bloku';
$_MODULE['<{blockpaymentlogo}leo_funiturestore>blockpaymentlogo_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{blockpaymentlogo}leo_funiturestore>blockpaymentlogo_b13fca921e8a4547cf90ca42a8b68b8a'] = 'Akceptujemy';
