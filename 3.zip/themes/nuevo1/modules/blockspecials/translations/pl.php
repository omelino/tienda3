<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_c19ed4ea98cbf319735f6d09bde6c757'] = 'Blok promocji';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_f5bae06098deb9298cb9ceca89171944'] = 'Dodaje blok wyświetlający aktualnie przecenione produkty.';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_c888438d14855d7d96a2724ee9c306bd'] = 'Zaktualizowano ustawienia';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_24ff4e4d39bb7811f6bdf0c189462272'] = 'Zawsze wyświetlaj ten blok';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_53d61d1ac0507b1bd8cd99db8d64fb19'] = 'Pokaż blok nawet jeżeli żaden produkt nie jest dostępny.';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Włączony';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_b9f5c797ebbf55adccdd8539a65a0241'] = 'Wyłączony';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_61465481ac2491b37e4517960bbd4a14'] = 'Ilość plików w buforze';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_e80a11f1704b88ad50f8fc6ce0f43525'] = 'Okazje specjalne są losowo wyświetlane na stronie głównej, ale ponieważ zajmuje to wiele zasobów, lepiej jest buforować wyniki. Bufor jest opróżniany każdego dnia.';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_26986c3388870d4148b1b5375368a83d'] = 'Wyświetlane produkty';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_63c150b9c1204c4825ce5914aed20717'] = 'Zdefiniuj liczbę produktów do wyświetlenia w tym bloku na stronie głównej.';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials-home_e420850bc0f6c94eff7edb2041b206bd'] = 'Brak promowanych produktów w tym momencie.';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_d1aa22a3126f04664e0fe3f598994014'] = 'Promocje';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_b4f95c1ea534936cc60c6368c225f480'] = 'Wszystkie promocje';
$_MODULE['<{blockspecials}leo_funiturestore>blockspecials_3c9f5a6dc6585f75042bd4242c020081'] = 'Aktualnie brak promocji.';
$_MODULE['<{blockspecials}leo_funiturestore>tab_d1aa22a3126f04664e0fe3f598994014'] = 'Promocje';
