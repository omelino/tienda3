<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Bloco de banner';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_9ec3d0f07db2d25a37ec4b7a21c788f8'] = 'Mostra um banner no topo da loja.';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'Ocorreu um erro ao enviar o arquivo.';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Configurações atualizadas';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Configurações';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_9edcdbdff24876b0dac92f97397ae497'] = 'Imagem de banner do topo';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_e90797453e35e4017b82e54e2b216290'] = 'Enviar uma imagem para seu banner do topo. Recomendamos as dimensões de 1170 x 65 px se você estiver usando o tema padrão.';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_46fae48f998058600248a16100acfb7e'] = 'Link do banner';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_084fa1da897dfe3717efa184616ff91c'] = 'Insira o link associado ao seu banner. Ao clicar no banner,o link abre na mesma janela. Se não inserir nenhum link, será redirecionado para a página inicial.';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_ff09729bee8a82c374f6b61e14a4af76'] = 'Descrição do banner';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Por favor digite uma descrição curta, mas significativa para o banner.';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar';
