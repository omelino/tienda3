<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Block Banner';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_9ec3d0f07db2d25a37ec4b7a21c788f8'] = 'Zeigt ein Banner im Header des Shops an.';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'Fehler beim Hochladen der Datei';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Einstellungen wurden aktualisiert.';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_9edcdbdff24876b0dac92f97397ae497'] = 'Banner-Bild im Header';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_e90797453e35e4017b82e54e2b216290'] = 'Laden Sie eine Bilddatei für das Banner im Kopfbereich hoch. Die empfohlene Größe der Bilddatei ist 1170 x 65px wenn Sie das Standard-Theme nutzen.';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_46fae48f998058600248a16100acfb7e'] = 'Banner-Link';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_084fa1da897dfe3717efa184616ff91c'] = 'Geben Sie eine Verlinkung für Ihr Banner ein. Beim Anklicken des Banners öffnet sich die Zielseite im gleichen Fenster. Wenn kein Link angegeben ist, wird zur Startseite umgeleitet.';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_ff09729bee8a82c374f6b61e14a4af76'] = 'Beschreibung';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Bitte geben Sie eine kurze, treffende Bescheibung für das Banner ein.';
$_MODULE['<{blockbanner}leo_funiturestore>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
