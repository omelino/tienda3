<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocktags}leo_funiturestore>blocktags_f2568a62d4ac8d1d5b532556379772ba'] = 'Blocco tags';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_b2de1a21b938fcae9955206a4ca11a12'] = 'Aggiunge un blocco contenente i tag del tuo prodotto.';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_8d731d453cacf8cff061df22a269b82b'] = 'Completare il campo \"Tag visualizzati\".';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_73293a024e644165e9bf48f270af63a0'] = 'Numero non valido.';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_fb3855930920fd1ef34c4904ef230802'] = 'Completa il campo \"Livelli tags\".';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_feb6da9d1dab0d22293d1da205fa1bb2'] = 'Valore non valido per \"Livelli tags\". Scegli un numero intero positivo.';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_08d5df9c340804cbdd62c0afc6afa784'] = 'Completa il campo \"Randomize\".';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_5c35c840e2d37e5cb3b6e1cf8aa78880'] = 'Valore non valido per \"Randomize\". Deve essere un operatore booleano.';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_726cefc6088fc537bc5b18f333357724'] = 'Tag visualizzati';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_34a51d24608287f9b34807c3004b39d9'] = 'Imposta il numero di tags che desideri siano mostrati in questo blocco (predefinito: 10).';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_ed7a7c842913f44b32b0f06d5a369dcf'] = 'Livelli tags';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_d088d9f9a8634d69a2aa0b11883fb6b1'] = 'Imposta il numero dei differenti livelli di tags che desideri utilizzare (predefinito: 3)';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_ac5bf3b321fa29adf8af5c825d670e76'] = 'Visualizzazione casuale';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_d4a9f41f7f8d2a65cda97d8b5eb0c9d5'] = 'Se abilitato, mostra in maniera casuale i tags. Come impostazione predefinita, la visualizzazione casuale è disabilitata e vengono mostrati per primi i tags più utilizzati.';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Attivato';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disattivato';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_189f63f277cd73395561651753563065'] = 'Tags';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'Maggiori informazioni su';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_4e6307cfde762f042d0de430e82ba854'] = 'Nessun tag ancora specificato.';
$_MODULE['<{blocktags}leo_funiturestore>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'Nessun tag ancora specificato';
