<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockstore}leo_funiturestore>blockstore_68e9ecb0ab69b1121fe06177868b8ade'] = 'مخزن كتلة محدد';
$_MODULE['<{blockstore}leo_funiturestore>blockstore_c1104fe0bdaceb2e1c6f77b04977b64b'] = 'يعرض رابط الصورة لميزة فروعنا بريستاشوب ل.';
$_MODULE['<{blockstore}leo_funiturestore>blockstore_b786bfc116ecf9a6d47ce1114ca6abb7'] = 'تحتاج هذه الوحدة ليكون مدمن مخدرات في عمود، ولكن الموضوع الخاص بك لا يقوم واحد.';
$_MODULE['<{blockstore}leo_funiturestore>blockstore_7107f6f679c8d8b21ef6fce56fef4b93'] = 'صورة غير صالحة.';
$_MODULE['<{blockstore}leo_funiturestore>blockstore_df7859ac16e724c9b1fba0a364503d72'] = 'حدث خطأ في ملف التحميل';
$_MODULE['<{blockstore}leo_funiturestore>blockstore_efc226b17e0532afff43be870bff0de7'] = 'تم تعديل الاعدادات بنحاج';
$_MODULE['<{blockstore}leo_funiturestore>blockstore_f4f70727dc34561dfde1a3c529b6205c'] = 'الإعدادات';
$_MODULE['<{blockstore}leo_funiturestore>blockstore_4d100d8b1b9bcb5a376f78365340cdbe'] = 'صورة لكتلة فروعنا';
$_MODULE['<{blockstore}leo_funiturestore>blockstore_a34202cc413553fe0fe2d46f706db435'] = 'النص لكتلة فروعنا';
$_MODULE['<{blockstore}leo_funiturestore>blockstore_c9cc8cce247e49bae79f15173ce97354'] = 'حفظ';
$_MODULE['<{blockstore}leo_funiturestore>blockstore_8c0caec5616160618b362bcd4427d97b'] = 'محلاتنا التجارية';
$_MODULE['<{blockstore}leo_funiturestore>blockstore_28fe12f949fd191685071517628df9b3'] = 'مشاهدة المزيد';
$_MODULE['<{blockstore}leo_funiturestore>blockstore_34c869c542dee932ef8cd96d2f91cae6'] = 'متاجرنا';
$_MODULE['<{blockstore}leo_funiturestore>blockstore_61d5070a61ce6eb6ad2a212fdf967d92'] = 'مشاهدة المزيد';
