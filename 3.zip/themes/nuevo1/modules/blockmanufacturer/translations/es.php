<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_bc3e73cfa718a3237fb1d7e1da491395'] = 'Bloque de marcas';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_71087c7035e626bd33c72ae9a7f042af'] = 'Mostrar bloque de marcas';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_f8c922e47935b3b76a749334045d61cf'] = 'número de elementos no válido.';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_5b2e13ff6fa0da895d14bd56f2cb2d2d'] = 'Por favor, elija al menos uno de la lista';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_f38f5974cdc23279ffe6d203641a8bdf'] = 'Ajustes actualizados.';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_bfdff752293014f11f17122c92909ad5'] = 'Use una lista de texto plano';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_a7c6946ecc7f4ed19c2691a1e7a28f97'] = 'Ver los fabricantes en una lista de texto sin formato.';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_2eef734f174a02ae3d7aaafefeeedb42'] = 'Número de elementos a mostrar';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_b0fa976774d2acf72f9c62e9ab73de38'] = 'Usar menu desplegable';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_56353167778d1520bfecc70c470e6d8a'] = 'Mostrar fabricantes en un menu desplegable.';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Fabricantes';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_c70ad5f80e4c6f299013e08cabc980df'] = 'Más acerca de %s';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_bf24faeb13210b5a703f3ccef792b000'] = 'Todos los fabricantes';
$_MODULE['<{blockmanufacturer}leo_funiturestore>blockmanufacturer_1c407c118b89fa6feaae6b0af5fc0970'] = 'Sin fabricante';
