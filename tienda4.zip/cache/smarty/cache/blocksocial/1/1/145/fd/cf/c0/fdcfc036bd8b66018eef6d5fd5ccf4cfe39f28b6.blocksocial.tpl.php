<?php /*%%SmartyHeaderCode:896757ab77bfd6c573-78974248%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fdcfc036bd8b66018eef6d5fd5ccf4cfe39f28b6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\themes\\nuevo1\\modules\\blocksocial\\blocksocial.tpl',
      1 => 1470855044,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '896757ab77bfd6c573-78974248',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab77c7c58c56_17625910',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab77c7c58c56_17625910')) {function content_57ab77c7c58c56_17625910($_smarty_tpl) {?>
<div id="social_block"> 	
	<ul>
					<li class="facebook">
				<a href="http://www.facebook.com/prestashop" class="btn-tooltip _blank">
					<span>Facebook</span>
				</a>
			</li>
							<li class="twitter">
				<a href="http://www.twitter.com/prestashop" class="btn-tooltip _blank">
					<span>Twitter</span>
				</a>
			</li>
							<li class="rss">
				<a href="http://www.prestashop.com/blog/en/" class="btn-tooltip _blank">
					<span>RSS</span>
				</a>
			</li>
		                        	<li class="google-plus">
        		<a href="https://www.google.com/+prestashop" class="btn-tooltip _blank">
        			<span>Google Plus</span>
        		</a>
        	</li>
                                	</ul>
</div>

<?php }} ?>
