<?php /*%%SmartyHeaderCode:1164857ab701d56d429-40302278%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a5cabe97cdca7dd05fbaafe6de7f2ba7bca81ad3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\modules\\blockbanner\\blockbanner.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1164857ab701d56d429-40302278',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab77c8690702_22758512',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab77c8690702_22758512')) {function content_57ab77c8690702_22758512($_smarty_tpl) {?><a href="http://localhost/tienda3/" title="">
	<img class="img-responsive" src="http://localhost/tienda3/modules/blockbanner/img/sale70.png" alt="" title="" width="1170" height="65" />
</a>
<?php }} ?>
