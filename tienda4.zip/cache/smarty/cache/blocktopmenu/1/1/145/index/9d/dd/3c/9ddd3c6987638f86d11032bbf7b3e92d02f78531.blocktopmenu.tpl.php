<?php /*%%SmartyHeaderCode:2764757ab77c092aa86-01659876%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9ddd3c6987638f86d11032bbf7b3e92d02f78531' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\themes\\nuevo1\\modules\\blocktopmenu\\blocktopmenu.tpl',
      1 => 1470855044,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2764757ab77c092aa86-01659876',
  'variables' => 
  array (
    'MENU' => 0,
    'MENU_SEARCH' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab77c0965414_98518757',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab77c0965414_98518757')) {function content_57ab77c0965414_98518757($_smarty_tpl) {?>	<!-- Menu -->
	<div id="block_top_menu" class="sf-contener clearfix col-lg-12">
		<div class="cat-title">Menú</div>
		<ul class="sf-menu clearfix menu-content">
			<li><a href="http://localhost/tienda3/3-mujer" title="Mujer">Mujer</a><ul><li><a href="http://localhost/tienda3/4-tops" title="Tops">Tops</a><ul><li><a href="http://localhost/tienda3/5-camisetas" title="Camisetas">Camisetas</a></li><li><a href="http://localhost/tienda3/7-blusas" title="Blusas">Blusas</a></li></ul></li><li><a href="http://localhost/tienda3/8-vestidos" title="Vestidos">Vestidos</a><ul><li><a href="http://localhost/tienda3/9-vestidos-informales" title="Vestidos informales">Vestidos informales</a></li><li><a href="http://localhost/tienda3/10-vestidos-noche" title="Vestidos de noche">Vestidos de noche</a></li><li><a href="http://localhost/tienda3/11-vestidos-verano" title="Vestidos de verano">Vestidos de verano</a></li></ul></li><li class="category-thumbnail"><div><img src="http://localhost/tienda3/img/c/3-0_thumb.jpg" alt="Mujer" title="Mujer" class="imgm" /></div><div><img src="http://localhost/tienda3/img/c/3-1_thumb.jpg" alt="Mujer" title="Mujer" class="imgm" /></div></li></ul></li><li><a href="http://localhost/tienda3/8-vestidos" title="Vestidos">Vestidos</a><ul><li><a href="http://localhost/tienda3/9-vestidos-informales" title="Vestidos informales">Vestidos informales</a></li><li><a href="http://localhost/tienda3/10-vestidos-noche" title="Vestidos de noche">Vestidos de noche</a></li><li><a href="http://localhost/tienda3/11-vestidos-verano" title="Vestidos de verano">Vestidos de verano</a></li></ul></li><li><a href="http://localhost/tienda3/5-camisetas" title="Camisetas">Camisetas</a></li>
					</ul>
	</div>
	<!--/ Menu -->
<?php }} ?>
