<?php /*%%SmartyHeaderCode:2354357ab77c20e9b40-91038803%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aa52011d15d5dfab89433e5f099be6b5c1007f97' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\themes\\nuevo1\\modules\\blocknewproducts\\blocknewproducts.tpl',
      1 => 1470855043,
      2 => 'file',
    ),
    '99e187efc59761a1b903805cce60539291573313' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\themes\\nuevo1\\sub\\product\\sidebar.tpl',
      1 => 1470855045,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2354357ab77c20e9b40-91038803',
  'variables' => 
  array (
    'link' => 0,
    'new_products' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab77c2120640_39358170',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab77c2120640_39358170')) {function content_57ab77c2120640_39358170($_smarty_tpl) {?><!-- MODULE Block new products -->
<div id="new-products_block_right" class="block products_block nopadding">
	<h4 class="title_block">
    	<a href="http://localhost/tienda3/nuevos-productos" title="Novedades">Novedades</a>
    </h4>
    <div class="block_content products-block">
                    <ul class="products products-block">
            <li class="clearfix media">
            
            <div class="product-block">

            <div class="product-container media" itemscope itemtype="https://schema.org/Product">
                 <a class="products-block-image img pull-left" href="http://localhost/tienda3/vestidos-noche/4-vestido-estampado.html" title=""><img class="replace-2x img-responsive" src="http://localhost/tienda3/10-small_default/vestido-estampado.jpg" alt="Vestido estampado" itemprop="image" />
                 </a>

                <div class="media-body">
                      <div class="product-content">
                        <h5 class="name media-heading" itemprop="name">
								<a class="product-name" href="http://localhost/tienda3/vestidos-noche/4-vestido-estampado.html" title="Vestido estampado" itemprop="url">
            			Vestido estampado</a>
                        </h5>
                         								<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                                            <span itemprop="price" class="product-price price">
                                    59,15 $                                </span>
                                                                <meta itemprop="priceCurrency" content="0" />
                                                    </div>
                                        </div>
                </div>
            </div>

              
            </div>    
        </li>
            <li class="clearfix media">
            
            <div class="product-block">

            <div class="product-container media" itemscope itemtype="https://schema.org/Product">
                 <a class="products-block-image img pull-left" href="http://localhost/tienda3/vestidos-verano/5-vestido-verano-estampado.html" title=""><img class="replace-2x img-responsive" src="http://localhost/tienda3/12-small_default/vestido-verano-estampado.jpg" alt="Vestido de verano estampado" itemprop="image" />
                 </a>

                <div class="media-body">
                      <div class="product-content">
                        <h5 class="name media-heading" itemprop="name">
								<a class="product-name" href="http://localhost/tienda3/vestidos-verano/5-vestido-verano-estampado.html" title="Vestido de verano estampado" itemprop="url">
            			Vestido de verano...</a>
                        </h5>
                         								<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                                            <span itemprop="price" class="product-price price">
                                    33,62 $                                </span>
                                                                    <span class="old-price product-price">
                                        35,39 $
                                    </span>
                                                                <meta itemprop="priceCurrency" content="0" />
                                                    </div>
                                        </div>
                </div>
            </div>

              
            </div>    
        </li>
            <li class="clearfix media">
            
            <div class="product-block">

            <div class="product-container media" itemscope itemtype="https://schema.org/Product">
                 <a class="products-block-image img pull-left" href="http://localhost/tienda3/vestidos-verano/6-vestido-verano-estampado.html" title=""><img class="replace-2x img-responsive" src="http://localhost/tienda3/16-small_default/vestido-verano-estampado.jpg" alt="Vestido de verano estampado" itemprop="image" />
                 </a>

                <div class="media-body">
                      <div class="product-content">
                        <h5 class="name media-heading" itemprop="name">
								<a class="product-name" href="http://localhost/tienda3/vestidos-verano/6-vestido-verano-estampado.html" title="Vestido de verano estampado" itemprop="url">
            			Vestido de verano...</a>
                        </h5>
                         								<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                                            <span itemprop="price" class="product-price price">
                                    35,38 $                                </span>
                                                                <meta itemprop="priceCurrency" content="0" />
                                                    </div>
                                        </div>
                </div>
            </div>

              
            </div>    
        </li>
            <li class="clearfix media">
            
            <div class="product-block">

            <div class="product-container media" itemscope itemtype="https://schema.org/Product">
                 <a class="products-block-image img pull-left" href="http://localhost/tienda3/vestidos-verano/7-vestido-estampado-gasa.html" title=""><img class="replace-2x img-responsive" src="http://localhost/tienda3/20-small_default/vestido-estampado-gasa.jpg" alt="Vestido de gasa estampado" itemprop="image" />
                 </a>

                <div class="media-body">
                      <div class="product-content">
                        <h5 class="name media-heading" itemprop="name">
								<a class="product-name" href="http://localhost/tienda3/vestidos-verano/7-vestido-estampado-gasa.html" title="Vestido de gasa estampado" itemprop="url">
            			Vestido de gasa estampado</a>
                        </h5>
                         								<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                                            <span itemprop="price" class="product-price price">
                                    19,03 $                                </span>
                                                                    <span class="old-price product-price">
                                        23,78 $
                                    </span>
                                                                <meta itemprop="priceCurrency" content="0" />
                                                    </div>
                                        </div>
                </div>
            </div>

              
            </div>    
        </li>
            <li class="clearfix media">
            
            <div class="product-block">

            <div class="product-container media" itemscope itemtype="https://schema.org/Product">
                 <a class="products-block-image img pull-left" href="http://localhost/tienda3/vestidos-informales/3-vestido-estampado.html" title=""><img class="replace-2x img-responsive" src="http://localhost/tienda3/8-small_default/vestido-estampado.jpg" alt="Vestido estampado" itemprop="image" />
                 </a>

                <div class="media-body">
                      <div class="product-content">
                        <h5 class="name media-heading" itemprop="name">
								<a class="product-name" href="http://localhost/tienda3/vestidos-informales/3-vestido-estampado.html" title="Vestido estampado" itemprop="url">
            			Vestido estampado</a>
                        </h5>
                         								<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                                            <span itemprop="price" class="product-price price">
                                    30,16 $                                </span>
                                                                <meta itemprop="priceCurrency" content="0" />
                                                    </div>
                                        </div>
                </div>
            </div>

              
            </div>    
        </li>
            <li class="clearfix media">
            
            <div class="product-block">

            <div class="product-container media" itemscope itemtype="https://schema.org/Product">
                 <a class="products-block-image img pull-left" href="http://localhost/tienda3/blusas/2-blusa.html" title=""><img class="replace-2x img-responsive" src="http://localhost/tienda3/7-small_default/blusa.jpg" alt="Blusa" itemprop="image" />
                 </a>

                <div class="media-body">
                      <div class="product-content">
                        <h5 class="name media-heading" itemprop="name">
								<a class="product-name" href="http://localhost/tienda3/blusas/2-blusa.html" title="Blusa" itemprop="url">
            			Blusa</a>
                        </h5>
                         								<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                                            <span itemprop="price" class="product-price price">
                                    31,32 $                                </span>
                                                                <meta itemprop="priceCurrency" content="0" />
                                                    </div>
                                        </div>
                </div>
            </div>

              
            </div>    
        </li>
            <li class="clearfix media">
            
            <div class="product-block">

            <div class="product-container media" itemscope itemtype="https://schema.org/Product">
                 <a class="products-block-image img pull-left" href="http://localhost/tienda3/camisetas/1-camiseta-destenida-manga-corta.html" title=""><img class="replace-2x img-responsive" src="http://localhost/tienda3/1-small_default/camiseta-destenida-manga-corta.jpg" alt="Camiseta efecto desteñido de manga corta" itemprop="image" />
                 </a>

                <div class="media-body">
                      <div class="product-content">
                        <h5 class="name media-heading" itemprop="name">
								<a class="product-name" href="http://localhost/tienda3/camisetas/1-camiseta-destenida-manga-corta.html" title="Camiseta efecto desteñido de manga corta" itemprop="url">
            			Camiseta efecto...</a>
                        </h5>
                         								<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                                            <span itemprop="price" class="product-price price">
                                    19,15 $                                </span>
                                                                <meta itemprop="priceCurrency" content="0" />
                                                    </div>
                                        </div>
                </div>
            </div>

              
            </div>    
        </li>
    </ul>           
            <div class="lnk">
                <a href="http://localhost/tienda3/nuevos-productos" title="Todas los nuevos productos" class="btn btn-outline button button-small"><span>Todas los nuevos productos</span></a>
            </div>
            </div>
</div>
<!-- /MODULE Block new products --><?php }} ?>
