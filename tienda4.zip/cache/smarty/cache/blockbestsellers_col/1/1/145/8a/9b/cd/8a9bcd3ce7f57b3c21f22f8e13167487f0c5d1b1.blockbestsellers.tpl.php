<?php /*%%SmartyHeaderCode:1845357ab77c14c1e95-28326591%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8a9bcd3ce7f57b3c21f22f8e13167487f0c5d1b1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\themes\\nuevo1\\modules\\blockbestsellers\\blockbestsellers.tpl',
      1 => 1470855043,
      2 => 'file',
    ),
    '99e187efc59761a1b903805cce60539291573313' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\themes\\nuevo1\\sub\\product\\sidebar.tpl',
      1 => 1470855045,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1845357ab77c14c1e95-28326591',
  'variables' => 
  array (
    'link' => 0,
    'best_sellers' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab77c1590f43_55956758',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab77c1590f43_55956758')) {function content_57ab77c1590f43_55956758($_smarty_tpl) {?>
<!-- MODULE Block best sellers -->
<div id="best-sellers_block_right" class="block products_block">
	<h4 class="title_block">
    	<a href="http://localhost/tienda3/mas-vendido" title="Ver los productos más vendidos">¡Lo más vendido!</a>
    </h4>
	<div class="block_content products-block">
		  	<ul class="products products-block">
            <li class="clearfix media">
            
            <div class="product-block">

            <div class="product-container media" itemscope itemtype="https://schema.org/Product">
                 <a class="products-block-image img pull-left" href="http://localhost/tienda3/blusas/2-blusa.html" title=""><img class="replace-2x img-responsive" src="http://localhost/tienda3/7-small_default/blusa.jpg" alt="Blusa" itemprop="image" />
                 </a>

                <div class="media-body">
                      <div class="product-content">
                        <h5 class="name media-heading" itemprop="name">
								<a class="product-name" href="http://localhost/tienda3/blusas/2-blusa.html" title="Blusa" itemprop="url">
            			Blusa</a>
                        </h5>
                         								<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                                            <span itemprop="price" class="product-price price">
                                    31,32 $                                </span>
                                                                <meta itemprop="priceCurrency" content="0" />
                                                    </div>
                                        </div>
                </div>
            </div>

              
            </div>    
        </li>
            <li class="clearfix media">
            
            <div class="product-block">

            <div class="product-container media" itemscope itemtype="https://schema.org/Product">
                 <a class="products-block-image img pull-left" href="http://localhost/tienda3/vestidos-informales/3-vestido-estampado.html" title=""><img class="replace-2x img-responsive" src="http://localhost/tienda3/8-small_default/vestido-estampado.jpg" alt="Vestido estampado" itemprop="image" />
                 </a>

                <div class="media-body">
                      <div class="product-content">
                        <h5 class="name media-heading" itemprop="name">
								<a class="product-name" href="http://localhost/tienda3/vestidos-informales/3-vestido-estampado.html" title="Vestido estampado" itemprop="url">
            			Vestido estampado</a>
                        </h5>
                         								<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                                            <span itemprop="price" class="product-price price">
                                    30,16 $                                </span>
                                                                <meta itemprop="priceCurrency" content="0" />
                                                    </div>
                                        </div>
                </div>
            </div>

              
            </div>    
        </li>
            <li class="clearfix media">
            
            <div class="product-block">

            <div class="product-container media" itemscope itemtype="https://schema.org/Product">
                 <a class="products-block-image img pull-left" href="http://localhost/tienda3/camisetas/1-camiseta-destenida-manga-corta.html" title=""><img class="replace-2x img-responsive" src="http://localhost/tienda3/1-small_default/camiseta-destenida-manga-corta.jpg" alt="Camiseta efecto desteñido de manga corta" itemprop="image" />
                 </a>

                <div class="media-body">
                      <div class="product-content">
                        <h5 class="name media-heading" itemprop="name">
								<a class="product-name" href="http://localhost/tienda3/camisetas/1-camiseta-destenida-manga-corta.html" title="Camiseta efecto desteñido de manga corta" itemprop="url">
            			Camiseta efecto...</a>
                        </h5>
                         								<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                                            <span itemprop="price" class="product-price price">
                                    19,15 $                                </span>
                                                                <meta itemprop="priceCurrency" content="0" />
                                                    </div>
                                        </div>
                </div>
            </div>

              
            </div>    
        </li>
            <li class="clearfix media">
            
            <div class="product-block">

            <div class="product-container media" itemscope itemtype="https://schema.org/Product">
                 <a class="products-block-image img pull-left" href="http://localhost/tienda3/vestidos-verano/7-vestido-estampado-gasa.html" title=""><img class="replace-2x img-responsive" src="http://localhost/tienda3/20-small_default/vestido-estampado-gasa.jpg" alt="Vestido de gasa estampado" itemprop="image" />
                 </a>

                <div class="media-body">
                      <div class="product-content">
                        <h5 class="name media-heading" itemprop="name">
								<a class="product-name" href="http://localhost/tienda3/vestidos-verano/7-vestido-estampado-gasa.html" title="Vestido de gasa estampado" itemprop="url">
            			Vestido de gasa estampado</a>
                        </h5>
                         								<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                                            <span itemprop="price" class="product-price price">
                                    19,03 $                                </span>
                                                                    <span class="old-price product-price">
                                        23,78 $
                                    </span>
                                                                <meta itemprop="priceCurrency" content="0" />
                                                    </div>
                                        </div>
                </div>
            </div>

              
            </div>    
        </li>
            <li class="clearfix media">
            
            <div class="product-block">

            <div class="product-container media" itemscope itemtype="https://schema.org/Product">
                 <a class="products-block-image img pull-left" href="http://localhost/tienda3/vestidos-verano/6-vestido-verano-estampado.html" title=""><img class="replace-2x img-responsive" src="http://localhost/tienda3/16-small_default/vestido-verano-estampado.jpg" alt="Vestido de verano estampado" itemprop="image" />
                 </a>

                <div class="media-body">
                      <div class="product-content">
                        <h5 class="name media-heading" itemprop="name">
								<a class="product-name" href="http://localhost/tienda3/vestidos-verano/6-vestido-verano-estampado.html" title="Vestido de verano estampado" itemprop="url">
            			Vestido de verano...</a>
                        </h5>
                         								<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                                            <span itemprop="price" class="product-price price">
                                    35,38 $                                </span>
                                                                <meta itemprop="priceCurrency" content="0" />
                                                    </div>
                                        </div>
                </div>
            </div>

              
            </div>    
        </li>
            <li class="clearfix media">
            
            <div class="product-block">

            <div class="product-container media" itemscope itemtype="https://schema.org/Product">
                 <a class="products-block-image img pull-left" href="http://localhost/tienda3/vestidos-verano/5-vestido-verano-estampado.html" title=""><img class="replace-2x img-responsive" src="http://localhost/tienda3/12-small_default/vestido-verano-estampado.jpg" alt="Vestido de verano estampado" itemprop="image" />
                 </a>

                <div class="media-body">
                      <div class="product-content">
                        <h5 class="name media-heading" itemprop="name">
								<a class="product-name" href="http://localhost/tienda3/vestidos-verano/5-vestido-verano-estampado.html" title="Vestido de verano estampado" itemprop="url">
            			Vestido de verano...</a>
                        </h5>
                         								<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
                                                            <span itemprop="price" class="product-price price">
                                    33,62 $                                </span>
                                                                    <span class="old-price product-price">
                                        35,39 $
                                    </span>
                                                                <meta itemprop="priceCurrency" content="0" />
                                                    </div>
                                        </div>
                </div>
            </div>

              
            </div>    
        </li>
    </ul>  
		<div class="lnk">
        	<a href="http://localhost/tienda3/mas-vendido" title="Los productos más vendidos"  class="btn btn-outline button button-small"><span>Los productos más vendidos</span></a>
        </div>
		</div>
</div>
<!-- /MODULE Block best sellers --><?php }} ?>
