<?php /*%%SmartyHeaderCode:2123157ab77c472bce1-29295798%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5955915735f5a970838839f49989958872bf3473' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\themes\\nuevo1\\product-list-colors.tpl',
      1 => 1470855044,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2123157ab77c472bce1-29295798',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab77c6684456_20921972',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab77c6684456_20921972')) {function content_57ab77c6684456_20921972($_smarty_tpl) {?><ul class="color_to_pick_list clearfix">
									<li>
				<a href="http://localhost/tienda3/vestidos-noche/4-vestido-estampado.html#/1-size-s/7-color-beige" id="color_16" class="color_pick" style="background:#f5f5dc;">
									</a>
			</li>
											<li>
				<a href="http://localhost/tienda3/vestidos-noche/4-vestido-estampado.html#/1-size-s/24-color-rosa" id="color_43" class="color_pick" style="background:#FCCACD;">
									</a>
			</li>
			</ul>
<?php }} ?>
