<?php /*%%SmartyHeaderCode:2123157ab77c472bce1-29295798%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5955915735f5a970838839f49989958872bf3473' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\themes\\nuevo1\\product-list-colors.tpl',
      1 => 1470855044,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2123157ab77c472bce1-29295798',
  'variables' => 
  array (
    'colors_list' => 0,
    'col_img_dir' => 0,
    'color' => 0,
    'link' => 0,
    'img_color_exists' => 0,
    'img_col_dir' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab77c65e41b6_97980111',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab77c65e41b6_97980111')) {function content_57ab77c65e41b6_97980111($_smarty_tpl) {?><ul class="color_to_pick_list clearfix">
									<li>
				<a href="http://localhost/tienda3/blusas/2-blusa.html#/1-size-s/8-color-blanco" id="color_8" class="color_pick" style="background:#ffffff;">
									</a>
			</li>
											<li>
				<a href="http://localhost/tienda3/blusas/2-blusa.html#/1-size-s/11-color-negro" id="color_7" class="color_pick" style="background:#434A54;">
									</a>
			</li>
			</ul>
<?php }} ?>
