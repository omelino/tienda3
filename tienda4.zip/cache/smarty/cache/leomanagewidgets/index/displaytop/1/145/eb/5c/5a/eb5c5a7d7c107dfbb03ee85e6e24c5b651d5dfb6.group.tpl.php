<?php /*%%SmartyHeaderCode:2592657ab77bfb1e761-69173215%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eb5c5a7d7c107dfbb03ee85e6e24c5b651d5dfb6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\modules\\leomanagewidgets\\views\\widgets\\group.tpl',
      1 => 1470854972,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2592657ab77bfb1e761-69173215',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab77c0b68e97_28398598',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab77c0b68e97_28398598')) {function content_57ab77c0b68e97_28398598($_smarty_tpl) {?>
            <div class="" 
                    >
            
                                                                                    <div class="widget col-lg-7-2 col-md-9-6 col-sm-9-6 col-xs-12 col-sp-12 hidden-xs hidden-sp"
                            >
                                                                                                <div class="widget-html block">
		<div class="custom_content">
		<div class="box-services"><a class="pull-left" href="#"> <span class="icon-shipping"> </span> </a>
<div class="media-body">
<h4>Envío gratis</h4>
<small>Ordenar ahora</small></div>
</div>
<div class="box-services"><a class="pull-left" href="#"> <span class="icon-service"> </span> </a>
<div class="media-body">
<h4>30 Devoluciones Día</h4>
<small>Para un carro de lisa</small></div>
</div>
<div class="box-services"><a class="pull-left" href="#"> <span class="icon-customer"> </span> </a>
<div class="media-body">
<h4>Pago seguro</h4>
<small>Para un carro de lisa</small></div>
</div>
	</div>
</div>
                                                                                    </div>
                                                        </div>
    <?php }} ?>
