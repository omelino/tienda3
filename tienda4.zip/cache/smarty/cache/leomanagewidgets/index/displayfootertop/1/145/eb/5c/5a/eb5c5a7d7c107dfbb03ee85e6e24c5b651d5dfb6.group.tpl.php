<?php /*%%SmartyHeaderCode:2592657ab77bfb1e761-69173215%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eb5c5a7d7c107dfbb03ee85e6e24c5b651d5dfb6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\modules\\leomanagewidgets\\views\\widgets\\group.tpl',
      1 => 1470854972,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2592657ab77bfb1e761-69173215',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab77bfe8d6b1_00594805',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab77bfe8d6b1_00594805')) {function content_57ab77bfe8d6b1_00594805($_smarty_tpl) {?>
            <div class="row" 
                    >
            
                                                                                    <div class="widget col-lg-3 col-md-3 col-sm-4 col-xs-4 col-sp-12"
                            >
                                                                                                <div id="social_block"> 	
	<ul>
					<li class="facebook">
				<a href="http://www.facebook.com/prestashop" class="btn-tooltip _blank">
					<span>Facebook</span>
				</a>
			</li>
							<li class="twitter">
				<a href="http://www.twitter.com/prestashop" class="btn-tooltip _blank">
					<span>Twitter</span>
				</a>
			</li>
							<li class="rss">
				<a href="http://www.prestashop.com/blog/en/" class="btn-tooltip _blank">
					<span>RSS</span>
				</a>
			</li>
		                        	<li class="google-plus">
        		<a href="https://www.google.com/+prestashop" class="btn-tooltip _blank">
        			<span>Google Plus</span>
        		</a>
        	</li>
                                	</ul>
</div>

                                                                                    </div>
                                                                                <div class="widget col-lg-9 col-md-9 col-sm-8 col-xs-8 col-sp-12 custhtmlcarosel"
                            >
                                                                                                <div id="custhtmlcarosel15417" class="block carousel custhtmlcarosel slide carousel-fade">
        	<a class="carousel-control left" href="#custhtmlcarosel15417"   data-slide="prev"></a>
	<a class="carousel-control right" href="#custhtmlcarosel15417"  data-slide="next"></a>
        <div class="carousel-inner">
            <div class="item active">
            <h4 class="title-custhtml">Title Sample 1</h4>
            <div class="custom-info">
<div class="text_people">
<p>Nunc in sem quis metus commodo blandit. Etiam lorem odio, varius sit amet eleifend vitae, varius at quam. Aliquam quis metus mauris. Class aptent taciti sociosqu per inceptos himenaeos.</p>
</div>
<div class="time">
<p>08:36 am, Jun 05, 2014</p>
</div>
</div>           
        </div>

            <div class="item ">
            <h4 class="title-custhtml">Title Sample 2</h4>
            <div class="custom-info">
<div class="text_people">
<p>Class aptent taciti sociosqu ad litora torquent per conia nostra, per inceptos himenaeos. varius sit amet eleifend vitae, varius at quam. Aliquam quis metus mauris.</p>
</div>
<div class="time">
<p>08:36 am, Jun 05, 2014</p>
</div>
</div>           
        </div>

            <div class="item ">
            <h4 class="title-custhtml">Title Sample 3</h4>
            <div class="custom-info">
<div class="text_people">
<p>Nunc in sem quis metus commodo blandit. Etiam lorem odio, varius sit amet eleifend vitae, varius at quam. Aliquam quis metus mauris. Class aptent taciti sociosqu , per inceptos himenaeos.</p>
</div>
<div class="time">
<p>08:36 am, Jun 05, 2014</p>
</div>
</div>           
        </div>

            <div class="item ">
            <h4 class="title-custhtml">Title Sample 4</h4>
            <div class="custom-info">
<div class="text_people">
<p>Class aptent taciti sociosqu ad litora torquent per conia nostra, per inceptos himenaeos. Nunc in sem quis metus commodo blandit. Aliquam quis metus mauris.</p>
</div>
<div class="time">
<p>08:36 am, Jun 05, 2014</p>
</div>
</div>           
        </div>

            <div class="item ">
            <h4 class="title-custhtml">Title Sample 5</h4>
            <div class="custom-info">
<div class="text_people">
<p>Nunc in sem quis metus commodo blandit. Class aptent taciti sociosqu ad litora torquent . Etiam lorem odio, varius sit varius at quam. Aliquam quis metus mauris.</p>
</div>
<div class="time">
<p>08:36 am, Jun 05, 2014</p>
</div>
</div>           
        </div>

       
    </div>
</div>
<script type="text/javascript">

$(document).ready(function() {
    $('#custhtmlcarosel15417').each(function(){
        $(this).carousel({
            pause: true,
            interval: false
        });
    });
     
});


</script>                                                                                    </div>
                                                        </div>
    <?php }} ?>
