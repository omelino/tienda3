<?php /*%%SmartyHeaderCode:2592657ab77bfb1e761-69173215%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eb5c5a7d7c107dfbb03ee85e6e24c5b651d5dfb6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\modules\\leomanagewidgets\\views\\widgets\\group.tpl',
      1 => 1470854972,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2592657ab77bfb1e761-69173215',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab77c00e5593_11018260',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab77c00e5593_11018260')) {function content_57ab77c00e5593_11018260($_smarty_tpl) {?>
            <div class="row" 
                    >
            
                                                                                    <div class="widget col-lg-3 col-md-3 col-sm-3 col-xs-6 col-sp-12"
                            >
                                                                                                <div class="widget-html block">
		<div class="custom_content">
		<h4 class="title_block">llámenos ahora al número gratuito:</h4>
<h2>(800) 2345-6789</h2>
	</div>
</div>
                                                                                    </div>
                                                                                <div class="widget col-lg-6 col-md-6 col-sm-6 col-xs-6 col-sp-12"
                            >
                                                                                                
<!-- Block Newsletter module-->

<div id="newsletter_block_left" class="inline">
        <h3>Get a newsletter</h3>  
	<form action="//localhost/tienda3/" method="post">
			<div class="form-group">
                <input class="inputNew newsletter-input form-control" id="newsletter-input" type="text" name="email" size="18" value="Introduzca su dirección de correo electrónico" />
                <button type="submit" class="button_mini btn" name="submitNewsletter">
                    <em class="fa fa-envelope-o">&nbsp;</em>
                    <span class="textnewsletter">Get a newsletter</span>
                </button>
                <input type="hidden" name="action" value="0" />
            </div>
        </form>

    
</div>
<!-- /Block Newsletter module-->
                                                                                    </div>
                                                                                <div class="widget col-lg-3 col-md-3 col-sm-3 col-xs-6 col-sp-12"
                            >
                                                                                                <div class="widget-html block">
		<h4 class="title_block">
		Pago Acepte
	</h4>
		<div class="custom_content">
		<p><a href="#"><img src="/tienda3/themes/ap_office/img/modules/leomanagewidgets/payment.png" alt="" /></a></p>
	</div>
</div>
                                                                                    </div>
                                                        </div>
    <?php }} ?>
