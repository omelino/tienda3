<?php /*%%SmartyHeaderCode:884257ab77c7a5ced1-79262487%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2192b3d022a0f2ee5cb09ff2a12dd352e76ecbea' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\themes\\nuevo1\\modules\\blockcontactinfos\\blockcontactinfos.tpl',
      1 => 1470855043,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '884257ab77c7a5ced1-79262487',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab77c81d56e9_34169552',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab77c81d56e9_34169552')) {function content_57ab77c81d56e9_34169552($_smarty_tpl) {?>
<!-- MODULE Block contact infos -->
<section id="block_contact_infos">
	<div>
        <ul>
            <img src="http://localhost/tienda3/themes/nuevo1/img/default/logo-footer.png" />
                        	<li class="company">
            		My Company, 42 Puffin street
12345 Puffinville
France            	</li>
                                    	<li class="phone">
            		<i class="fa fa-phone"></i>Llámanos ahora: 
            		<span>0123-456-789</span>
            	</li>
                                    	<li class="mail">
            		<i class="fa fa-envelope"></i>Email: 
            		<span><a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;%73%61%6c%65%73@%79%6f%75%72%63%6f%6d%70%61%6e%79.%63%6f%6d" >&#x73;&#x61;&#x6c;&#x65;&#x73;&#x40;&#x79;&#x6f;&#x75;&#x72;&#x63;&#x6f;&#x6d;&#x70;&#x61;&#x6e;&#x79;&#x2e;&#x63;&#x6f;&#x6d;</a></span>
            	</li>
                    </ul>
    </div>
</section>
<!-- /MODULE Block contact infos -->
<?php }} ?>
