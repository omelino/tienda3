<?php /*%%SmartyHeaderCode:2062557ab77c1adc803-35955680%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '40aea1d877bc83d2b3b423904c58724021afbfab' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\themes\\nuevo1\\modules\\blockcms\\blockcms.tpl',
      1 => 1470855043,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2062557ab77c1adc803-35955680',
  'variables' => 
  array (
    'block' => 0,
    'cms_titles' => 0,
    'cms_key' => 0,
    'cms_title' => 0,
    'cms_page' => 0,
    'link' => 0,
    'show_price_drop' => 0,
    'PS_CATALOG_MODE' => 0,
    'show_new_products' => 0,
    'show_best_sales' => 0,
    'display_stores_footer' => 0,
    'show_contact' => 0,
    'contact_url' => 0,
    'cmslinks' => 0,
    'cmslink' => 0,
    'show_sitemap' => 0,
    'display_poweredby' => 0,
    'footer_text' => 0,
  ),
  'has_nocache_code' => true,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab77c1c017c2_00024842',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab77c1c017c2_00024842')) {function content_57ab77c1c017c2_00024842($_smarty_tpl) {?>
	<!-- Block CMS module -->
			<div id="informations_block_left_1" class="block informations_block_left">
			<h4 class="title_block">
				<a href="http://localhost/tienda3/content/category/1-inicio">
					Información				</a>
			</h4>
			<div class="block_content list-block">
				<ul class="bullet">
																							<li>
								<a href="http://localhost/tienda3/content/1-entrega" title="Envío">
									Envío
								</a>
							</li>
																								<li>
								<a href="http://localhost/tienda3/content/2-aviso-legal" title="Aviso legal">
									Aviso legal
								</a>
							</li>
																								<li>
								<a href="http://localhost/tienda3/content/3-terminos-y-condiciones-de-uso" title="Términos y condiciones">
									Términos y condiciones
								</a>
							</li>
																								<li>
								<a href="http://localhost/tienda3/content/4-sobre-nosotros" title="Sobre nosotros">
									Sobre nosotros
								</a>
							</li>
																								<li>
								<a href="http://localhost/tienda3/content/5-pago-seguro" title="Pago seguro">
									Pago seguro
								</a>
							</li>
																						<li>
							<a href="http://localhost/tienda3/tiendas" title="Nuestras tiendas">
								Nuestras tiendas
							</a>
						</li>
									</ul>
			</div>
		</div>
		<!-- /Block CMS module -->
<?php }} ?>
