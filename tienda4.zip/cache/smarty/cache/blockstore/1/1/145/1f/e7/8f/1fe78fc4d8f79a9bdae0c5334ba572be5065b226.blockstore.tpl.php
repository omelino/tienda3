<?php /*%%SmartyHeaderCode:448257ab77c28c9711-57203636%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1fe78fc4d8f79a9bdae0c5334ba572be5065b226' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\themes\\nuevo1\\modules\\blockstore\\blockstore.tpl',
      1 => 1470855044,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '448257ab77c28c9711-57203636',
  'variables' => 
  array (
    'link' => 0,
    'module_dir' => 0,
    'store_img' => 0,
    'store_text' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab77c291f621_81414079',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab77c291f621_81414079')) {function content_57ab77c291f621_81414079($_smarty_tpl) {?>
<!-- Block stores module -->
<div id="stores_block_left" class="block">
	<h4 class="title_block">
		<a href="http://localhost/tienda3/tiendas" title="Nuestras tiendas">
			Nuestras tiendas
		</a>
	</h4>
	<div class="block_content blockstore">
		<p class="store_image">
			<a href="http://localhost/tienda3/tiendas" title="Nuestras tiendas">
				<img class="img-responsive" src="http://localhost/tienda3/modules/blockstore/store.jpg" alt="Nuestras tiendas" />
			</a>
		</p>
				<div>
			<a 
			class="btn btn-outline button button-small" 
			href="http://localhost/tienda3/tiendas" 
			title="Nuestras tiendas">
				<span>Descubra nuestras tiendas</span>
			</a>
		</div>
	</div>
</div>
<!-- /Block stores module -->
<?php }} ?>
