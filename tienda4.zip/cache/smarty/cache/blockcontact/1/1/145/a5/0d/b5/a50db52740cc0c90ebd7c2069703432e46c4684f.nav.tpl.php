<?php /*%%SmartyHeaderCode:3094657ab77c8836560-32072281%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a50db52740cc0c90ebd7c2069703432e46c4684f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tienda3\\themes\\nuevo1\\modules\\blockcontact\\nav.tpl',
      1 => 1470855043,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3094657ab77c8836560-32072281',
  'variables' => 
  array (
    'is_logged' => 0,
    'link' => 0,
    'telnumber' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab77c887ca77_75940052',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab77c887ca77_75940052')) {function content_57ab77c887ca77_75940052($_smarty_tpl) {?><div id="contact-link" >
	<a href="http://localhost/tienda3/contactanos" title="Contacte con nosotros">Contacte con nosotros</a>
</div>
	<span class="shop-phone">
		<i class="fa fa-phone"></i>Llámanos ahora: <strong>0123-456-789</strong>
	</span>
<?php }} ?>
